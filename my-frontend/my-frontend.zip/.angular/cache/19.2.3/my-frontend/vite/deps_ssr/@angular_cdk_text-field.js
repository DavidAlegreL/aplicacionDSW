import { createRequire } from 'module';const require = createRequire(import.meta.url);
import {
  AutofillMonitor,
  CdkAutofill,
  CdkTextareaAutosize,
  TextFieldModule
} from "./chunk-IQCZZQTI.js";
import "./chunk-6F23KLXY.js";
import "./chunk-FHXR5Z52.js";
import "./chunk-QPSQRP52.js";
import "./chunk-YHCV7DAQ.js";
export {
  AutofillMonitor,
  CdkAutofill,
  CdkTextareaAutosize,
  TextFieldModule
};
